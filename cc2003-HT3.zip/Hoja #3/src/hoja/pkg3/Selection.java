import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

class PruebaSelect {

	@Test
	void PruebaSelect() {
		ArrayList<String> i = new ArrayList<String>();
		ArrayList<String> respuesta = new ArrayList<String>();
		respuesta.add("1");
		respuesta.add("2");
		respuesta.add("3");
		respuesta.add("4");
		respuesta.add("5");
		ArrayList<String> lista = new ArrayList<String>();
		lista.add("5");
		lista.add("3");
		lista.add("2");
		lista.add("4");
		lista.add("1");
		String[] lista1 = test.selectionSort(lista);
		i.add(lista1[0]);
		i.add(lista1[1]);
		i.add(lista1[2]);
		i.add(lista1[3]);
		i.add(lista1[4]);
		
	}

}
