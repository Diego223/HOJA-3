/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hoja.pkg3;
import java.io.*;
import java.util.*;
import java.util.ArrayList;


/**
 *
 * @author diego
 */
public class Sortsitos {
    FileWriter fichero;
    PrintWriter writer;
    
   public ArrayList<String> GeneradorNumeros(int cantidad){
       Random rnd = new Random();
       ArrayList<String> numeros = new ArrayList<String>();
       
       for (int i = 0 ; i < cantidad ; i++){
           numeros.add(String.valueOf(rnd.nextInt(cantidad)));
                  
       }
       return numeros;

   }
   public void Escribir(ArrayList<String> datos){
       
       try{           
           fichero = new FileWriter("D:/ALGORITMOS/Hoja #3/src/hoja/pkg3/Numeros.txt");
           writer = new PrintWriter(fichero);
           
           for (int i = 0 ; i < datos.size(); i++)
           {
              writer.println(datos.get(i));           
           }
           System.out.println(datos);
       }
           catch(Exception e)  {System.out.println("No se pudo escribir el archivo");}                    

   }
   public String[] Selection(ArrayList<String> lista){ 
		int a = lista.size();
		String[] lista1 = new String[a];
		for (int i = 0; i < a; i++){
			lista1[i] = lista.get(i);
		}
		for (int i = 0; i < lista1.length - 1; i++){
			int peque = i;
	        for (int y = i + 1; y < lista.size(); y++){
	        	if (Integer.parseInt(lista1[y]) < Integer.parseInt(lista1[peque])){
	        		peque = y;
	        		}
	               }
	               if (i != peque) {
	            	   int aux= Integer.parseInt(lista1[i]);
	            	   lista1[i] = lista1[peque];
	            	   lista1[peque] = String.valueOf(aux);
	               }
	       }
		return lista1;
   
    
   }
   
   
   
   String [] Shell(ArrayList<String> lista){
		int a = lista.size();
		String[] lista1 = new String[a];
		for (int i = 0; i < a; i++){
			lista1[i] = lista.get(i);
		}
		boolean band;
		int x;
		int y;
		int c;
		x = lista1.length;
		while(x > 0){
			x = x / 2;
			band = true;
			while(band){
				band = false;
				y = 0;
				while ((y+x) <= lista1.length-1){
					if (Integer.parseInt(lista1[y]) > Integer.parseInt(lista1[y + x])){
						c = Integer.parseInt(lista1[y]);
						lista1[y] = lista1[y+x];
						lista1[y+x] = String.valueOf(c);
						band = true;
					}
					y = y + 1;
				}
			}
		}
		
		return lista1;
	}
   
   private int[] Quick(int[] lista, int first, int last){ 
		int y;
		int b;
		int q;
		int xx;
		boolean band;
		y = first;
		b = last;
		q = first;
		band = true;
		while(band){
			band = false;
			while ((lista[q] <= lista[q]) && (q != b)){
				b = b -1;
			}
			if(q != b){
				xx = lista[q];
				lista[q] = lista[b];
				lista[b]= xx;
				q = b;
				while((lista[q] >= lista[y]) 
						&& (q != y)){
					y = y +1;
				}
				if (q != y){
					band = true;
					xx = lista[q];
					lista[q] = lista[y];
					lista[y] = xx;
					q = y;
				}
			}
		}
		if ((q -1) > first){
			Quick(lista, first, q-1);  //RECURSION
		}
		if (last > (q+1)){
			Quick(lista, q+1, last); //RECURSION
		}
		return lista;
	}
   
   public int[] Radix(int[] lista, int n) { 
        for (int exp = 1; m / exp > 0; exp *= 10) {
        	
        }
        return lista;
    }
   




}
