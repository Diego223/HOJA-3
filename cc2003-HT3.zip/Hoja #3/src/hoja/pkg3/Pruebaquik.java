/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

class PruebaQuik {

	@Test
	void PruebaQuik() {
		int[] numeros;
		numeros = new int[] { 3, 1, 2, 5, 4};
		ArrayList<String> lista = new ArrayList<String>();
		ArrayList<String> r = new ArrayList<String>();
		lista.add("1");
		lista.add("2");
		lista.add("3");
		lista.add("4");
		lista.add("5");
		int[] lista1 = test.quicksort(numeros);
		r.add(String.valueOf(lista1[0]));
		r.add(String.valueOf(lista1[1]));
		r.add(String.valueOf(lista1[2]));
		r.add(String.valueOf(lista1[3]));
		r.add(String.valueOf(lista1[4]));
	}

}
